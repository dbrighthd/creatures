Creatures+ and Textures+ Discord server: https://discord.gg/WCvwtzW

 my youtube channel:https://www.youtube.com/channel/UCROOYAHYYupGE6AJAjl9XLQ


 

I am part of Retroboost/PewDiePack team, with some of these textures included in the PewDiePack, and many textures were made with advice from them. Join the Retroboost server at https://discord.gg/Jbc2hB2

 

Textures by SwiftShadowFox and dbrighthd

 

Minecraft earth textures from  U1timateJ7 and Ewan Howell

I used u/MushirMickeyJoe 's Alex husk as a base. check out their podcast Here

 

More Creature Textures added!

 

Dolphin:

+ Orca
+Amazon river dolphin
+beluga whale
+Narwhal

+Common Dolphin

 

Parrots:

 + Cockatoo

 + Blue Budgie/Parakeet

 + Yellow Budgie/Parakeet

 + Green Cheek Conure/Ari from JaidenAnimations

 +Tofu from JaidenAnimations
 + Sun Conure

 + Bald Eagle
 +Yellow Cockatiel (based on Momo, my friends bird who passed away)
 + Toucan
 + Puffin

 

Turtles:

 + Blue Flatback

 +  2 Hawksbill Turtle textures

 + Leatherback turtle

Wolves:

 + Pug

 + German Shepard

 + Huskie

 + Border collie

 + Yellow Lab

 + Dog Bandana (replaces collar when an exclamation point "!" is added to the name)

 + [MCE] Skeleton Dog (Only when named "Grim")

 + Soul Hound (When renamed to "Soul Hound")

Cats:

 + Tiger

 + wild ocelot as tamed cat

 + Gray Tabby

 + Tortoiseshell Cat

 + Dark Siamese Tabby

 + 3 Legged Dark Brown tabby

 

Cows:

+ [MCE] Albino Cow
+ [MCE] Ashen Cow
+ [MCE] Brule Cow
+ [MCE] Wooly Cow
+ [MCE] Cookie Cow
+ [MCE] Dairy Cow
+ [MCE] Sunset Cow
+ [MCE] Wooly Cow
+ [MCE] Pinto Cow

+ [MCE] Pink Moobloom (When renamed to "Pink Moobloom", or when spawned in a flower forest)
+ [MCE] Yellow Moobloom (When renamed to "Moobloom", or when spawned in a flower forest)

 

Pigs

 + [MCE] Muddy Pig
 + [MCE] Dried Muddy Pig
 + [MCE] Pale Pig
 + [MCE] Piebald Pig
 + [MCE] Mottled Pig
 + [MCE] Pink Footed Pig
 + [MCE] Sooty Pig
 + [MCE] Spotted Pig

 + Muddy variant for every pig

Fox
 + Raccoon

 + Badger

 + Red Panda

 

Bees:
+ Trans Pride Flag Bee
+ Gay Pride Flag Bee
+ Bi Pride Flag Bee
+ Lesbian Pride Flag Bee
+ Pan Pride Flag Bee
+ Asexual Pride Flag Bee
+ Straight(?) Pride Flag Bee
+ Non-binary Pride Flag Bee 

 

Other: 

 + [MCE] Jolly llama (Only when a llama is renamed to "Jolly")
 + [MCE] Horned Sheep
 + [MCE] Furnace Golem

+ [MCE] Glowing Squid

+ [MCE] Muddy Rabbit

+ [MCE] Vested Rabbit

+ Zombie horse (already exists in game, buit rename a horse to "Zorse" to make it a zombie horse)

+ Skeleton Donkeys and Mules when renamed to "Skelly"

Hostile Mobs:

 + Soul Blaze (Only when spawned in Soul Sand Valley)

 + Soul Skeletons (When spawned in Soul Sand Valley)

 + Alex Husk

 + Alex Zombie

 + [MCE] Bone Spider

 

More textures are coming

 

Other works of mine:

 

 Elytras+: https://www.curseforge.com/minecraft/texture-packs/elytras

 
